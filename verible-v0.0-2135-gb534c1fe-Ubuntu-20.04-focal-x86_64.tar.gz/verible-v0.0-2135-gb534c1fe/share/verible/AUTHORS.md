---
---

# This is the list of Verible authors for copyright purposes.
#
# This does not necessarily list everyone who has contributed code, since in
# some cases, their employer may be the copyright holder.  To see the full list
# of contributors, see the revision history in source control.
Google LLC
David Fang
Sergey Sokolov
Jonathan Mayer
Jeremy Colebrook-Soucie
Cameron Korzecke
Carissa Kathuria
Henner Zeller
